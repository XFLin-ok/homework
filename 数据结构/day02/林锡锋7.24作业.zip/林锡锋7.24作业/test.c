#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

// 数据类型
typedef int data_t;

// 数据节点类型
typedef struct data_node
{
    data_t data;
    struct data_node *next;
} data_node;
// 管理节点结构体类型
typedef struct mange_node
{
    struct data_node *head;
    struct data_node *tail;
    int num;
} mange_node;
// 创建管理节点
mange_node *mange_node_create()
{
    // 分配堆空间
    mange_node *mange = (mange_node *)malloc(1 * sizeof(mange_node));
    // 判断是否成功分配
    if (mange == NULL)
    {
        printf("create mange node fail\n");
        return NULL;
    }
    // 初始化
    mange->head = NULL;
    mange->tail = NULL;
    mange->num = 0;
    return mange;
}
// 创建新节点
data_node *data_node_create(data_t data)
{
    // 分配堆空间
    data_node *node = (data_node *)malloc(1 * sizeof(data_node));
    if (node == NULL)
    {
        printf("create node fail\n");
        return NULL;
    }
    // 初始化
    node->data = data;
    node->next = NULL;
    return node;
}
// 尾插法
bool tail_insert(mange_node *mange, data_t data)
{
    // 创建新节点
    data_node *newnode = data_node_create(data);
    if (newnode == NULL)
    {
        printf("create new node fail\n");
        return false;
    }
    // 空链表
    if (mange->head == NULL)
    {
        mange->head = newnode;
        mange->tail = newnode;
        mange->num++;
    }
    else // 非空链表
    {
        mange->tail->next = newnode;
        mange->tail = newnode;
        mange->num++;
    }
    return true;
}
// 头插法
bool head_insert(mange_node *mange, data_t data)
{
    // 创建节点
    data_node *newnode = data_node_create(data);
    if (newnode == NULL)
    {
        printf("create new node fail\n");
        return false;
    }
    // 空链表
    if (mange->head == NULL)
    {
        mange->head = newnode;
        mange->tail = newnode;
        mange->num++;
    }
    else // 非空链表
    {

        newnode->next = mange->head;
        mange->head = newnode;
        mange->num++;
    }
    return true;
}
// 删除节点
bool del_node(mange_node *mange, data_t data)
{
    data_node *q = mange->head;
    data_node *tmp = NULL;
    while (q != NULL)
    {
        if (q->data == data)
        {
            break;
        }
        tmp = q;
        q = q->next;
    }
    if (q == mange->head)
    {
        mange->head = q->next;
        q->next = NULL;
        mange->num--;
        free(q);
        printf("删除了数据为%d的节点\n", data);
    }
    else if (q == mange->tail)
    {
        mange->tail = tmp;
        tmp->next = NULL;
        mange->num--;
        free(q);
        printf("删除了数据为%d的节点\n", data);
    }
    else
    {
        tmp->next = q->next;
        q->next = NULL;
        mange->num--;
        free(q);
        printf("删除了数据为%d的节点\n", data);
    }
}
// 查询节点
bool search_node(mange_node *mange, data_t data)
{
    data_node *q1 = mange->head;
    int i = 0;
    while (q1 != NULL)
    {
        if (q1->data == data)
        {
            printf("找到%d为第%d个节点的数据\n", data, i + 1);
            return true;
        }
        i++;
        q1 = q1->next;
    }
    return false;
}
// 删除最小值节点
void del_mindata(mange_node *mange)
{
    data_node *q2 = mange->head;
    int min = q2->data;
    while (q2 != NULL)
    {
        if ((q2->data) < min)
        {
            min = q2->data;
        }
        q2 = q2->next;
    }
    printf("最小值为%d\n", min);
    del_node(mange, min);
}
// 打印链表
void print_linklist(mange_node *mange)
{
    data_node *p = mange->head;
    while (p != NULL)
    {
        printf("%d\t", p->data);
        p = p->next;
    }
    printf("\n");
}

int main()
{
    mange_node *mange = mange_node_create();
    tail_insert(mange, 10);
    tail_insert(mange, 20);
    tail_insert(mange, 30);

    head_insert(mange, 40);
    head_insert(mange, 50);
    head_insert(mange, 60);

    print_linklist(mange);

    search_node(mange, 30);
    search_node(mange, 40);
    search_node(mange, 60);

    del_node(mange, 20);

    print_linklist(mange);
    del_mindata(mange);
    print_linklist(mange);
    del_mindata(mange);
    print_linklist(mange);
}